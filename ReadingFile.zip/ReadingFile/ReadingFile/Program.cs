﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using AspNetCore.Http.Extensions;

namespace ReadingFile
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fileStream = new FileStream(@"C:\Users\sgnanala\Documents\BAckup\Gv\Free\EFSinput.txt", FileMode.Open);

            var parserList = new List<List<Configuration>>();

            using (StreamReader reader = new StreamReader(fileStream))
            {
                string line = "";

                while ((line = reader.ReadLine()) != null)
                {
                    var list = ParseLine(line);

                    parserList.Add(list);
                }
               
            }

            if (parserList != null && parserList.Any())
            {
                int walkerdtoLength=parserList.Count;
                walkerCollection walkerCollection = new walkerCollection();
                walkerCollection.WalkerList = new List<walker>();
                //List<walker> walkerdto = new List<walker>();
                //walker[] walkerdto = new walker[walkerdtoLength];
                foreach (var list in parserList)
                {
                    walker walkerobj = new walker();
                    walkerobj.SOURCE_PROGRAM = list[0].CalculatedValue;
                    walkerobj.BATCH_NO = list[3].CalculatedValue;
                    walkerobj.REFER_NO = list[4].CalculatedValue;
                    walkerCollection.WalkerList.Add(walkerobj);
                    //Console.WriteLine("New Line");
                    //if (list != null && list.Any())
                    //{
                    //    PrintValues(list);
                    //}
                    //CallWebAPIToPost(walkerobj);
                }
                CallWebAPIToPost(walkerCollection);
            }



            Console.ReadKey();
        }

        public static List<Configuration> ParseLine(string line)
        {

            ConfigurationList obj = new ConfigurationList();

            var configList = obj.GetConfigurationList();

            if (configList != null && configList.Count > 0)
            {
                foreach (var config in configList)
                {
                    config.CalculatedValue = line.SubstringByIndexes(config.StartPosition, config.EndPosition);
                }
            }

            return configList;

        }

        public static void PrintValues(List<Configuration> parsedList)
        {
            foreach (var parsed in parsedList)
            {
                string name = parsed.CalculatedValue;
                Console.WriteLine("{0} : {1}",parsed.PropertyName, parsed.CalculatedValue );
            }
        }

        public static void CallWebAPIToPost(walkerCollection dto)
        {
            using (var _httpClient = new HttpClient())
            {
                _httpClient.BaseAddress = new Uri("https://localhost:44327/api/walker");
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string testData = "Gv";
                string data= Serialize(dto);
                //HttpContent httpContent = new StringContent(data, Encoding.UTF8, "application/json");
                HttpContent httpContent = new StringContent(testData);
                HttpResponseMessage response = _httpClient.PostAsJsonAsync<walkerCollection>("https://localhost:44327/api/walker", dto).Result;
                //HttpResponseMessage response1 = _httpClient.postAsjsonAsync(apiUrl, postObject, token).Result;
                //HttpResponseMessage respobj = _httpClient.PostAsync(_httpClient.BaseAddress, dto);
           }

            

        }

        public static string Serialize(object obj)
        {
            ///// To parse base class object  
            var json = ParsePreDefinedClassObject(obj);

            ///// Null means it is not a base class object  
            if (!string.IsNullOrEmpty(json))
            {
                return json;
            }

            //// For parsing user defined class object  
            //// To get all properties of object  
            //// and then store object properties and their value in dictionary container  
            var objectDataContainer = obj.GetType().GetProperties().ToDictionary(i => i.Name, i => i.GetValue(obj));

            StringBuilder jsonfile = new StringBuilder();
            jsonfile.Append("{");
            foreach (var data in objectDataContainer)
            {
                jsonfile.Append($"\"{data.Key}\":{Serialize(data.Value)},");
            }

            //// To remove last comma  
            jsonfile.Remove(jsonfile.Length - 1, 1);
            jsonfile.Append("}");
            return jsonfile.ToString();
        }

        private static string ParsePreDefinedClassObject(object obj)
        {
            if (obj is null)
            {
                return "null";
            }
            if (IsJsonValueType(obj))
            {
                return obj.ToString().ToLower();
            }
            else if (IsJsonStringType(obj))
            {
                return $"\"{obj.ToString()}\"";
            }
            else if (obj is IDictionary)
            {
                return SearlizeDictionaryObject((IDictionary)obj);
            }
            else if (obj is IList || obj is Array)
            {
                return SearlizeListObject((IEnumerable)obj);
            }

            return null;
        }
        private static string SearlizeDictionaryObject(IDictionary dict)
        {
            StringBuilder jsonfile = new StringBuilder();
            jsonfile.Append("{");
            var keysAsJson = new List<string>();
            var valuesAsJson = new List<string>();
            foreach (var item in (IEnumerable)dict.Keys)
            {
                keysAsJson.Add(Serialize(item));
            }
            foreach (var item in (IEnumerable)dict.Values)
            {
                valuesAsJson.Add(Serialize(item));
            }
            for (int i = 0; i < dict.Count; i++)
            {
                ////To check whether data is under double quotes or not  
                keysAsJson[i] = keysAsJson[i].Contains("\"") ? keysAsJson[i] : $"\"{keysAsJson[i]}\"";

                jsonfile.Append($"{keysAsJson[i]}:{valuesAsJson[i]},");
            }
            jsonfile.Remove(jsonfile.Length - 1, 1);
            jsonfile.Append("}");
            return jsonfile.ToString();
        }

        /// <summary>  
        /// To Serialize Enumerable (IList,Array..etc) type object  
        /// </summary>  
        /// <param name="obj">object for serialization</param>  
        /// <returns>json string of object</returns>  
        private static string SearlizeListObject(IEnumerable obj)
        {
            StringBuilder jsonfile = new StringBuilder();
            jsonfile.Append("[");
            foreach (var item in obj)
            {
                jsonfile.Append($"{Serialize(item)},");
            }
            jsonfile.Remove(jsonfile.Length - 1, 1);
            jsonfile.Append("]");
            return jsonfile.ToString();
        }

        private static bool IsJsonStringType(object obj)
        {
            return obj is string || obj is DateTime;
        }

        private static bool IsJsonValueType(object obj)
        {
            return obj.GetType().IsPrimitive;
        }
    }

    public static class StringExtensions
    {
        public static string SubstringByIndexes(this string value, int startIndex, int endIndex)
        {
            try
            {
                return value.Substring(startIndex-1, endIndex - startIndex + 1);
            }
            catch (Exception ex)
            {
                return "";
            }
        }
    }
}
