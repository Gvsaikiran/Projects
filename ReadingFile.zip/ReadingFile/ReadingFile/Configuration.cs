﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadingFile
{
    public class Configuration
    {
        public string PropertyName { get; set; }

        public int StartPosition { get; set; }

        public int EndPosition { get; set; }

        public string CalculatedValue { get; set; }
    }
}
