﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadingFile
{
    class ConfigurationList
    {
        public List<Configuration> GetConfigurationList()
        {
            var list = new List<Configuration>();


            list.Add(new Configuration() { PropertyName = "SOURCE_PROGRAM", StartPosition = 1, EndPosition = 8 });
            list.Add(new Configuration() { PropertyName = "ISSUE_LOCN", StartPosition = 9, EndPosition = 13 });
            list.Add(new Configuration() { PropertyName = "EXPENSE_MONTH", StartPosition = 14, EndPosition = 15 });
            list.Add(new Configuration() { PropertyName = "BATCH_NO", StartPosition = 16, EndPosition = 18 });
            list.Add(new Configuration() { PropertyName = "REFER_NO", StartPosition = 19, EndPosition = 23 });
            list.Add(new Configuration() { PropertyName = "REF_SEQUENCE", StartPosition = 24, EndPosition = 25 });
            list.Add(new Configuration() { PropertyName = "SOURCE_TYPE", StartPosition = 26, EndPosition = 27 });
            list.Add(new Configuration() { PropertyName = "ACCOUNTING_MONTH", StartPosition = 28, EndPosition = 29 });
            list.Add(new Configuration() { PropertyName = "INVOICE_DRAFT_DATE", StartPosition = 30, EndPosition = 35 });
            list.Add(new Configuration() { PropertyName = "CHECK_DRAFT_NUMBER", StartPosition = 36, EndPosition = 41 });
            list.Add(new Configuration() { PropertyName = "DUE_DATE", StartPosition = 42, EndPosition = 47 });
            list.Add(new Configuration() { PropertyName = "PROCESS_DATE", StartPosition = 48, EndPosition = 53 });
            list.Add(new Configuration() { PropertyName = "PROCESS_TIME", StartPosition = 54, EndPosition = 59 });
            list.Add(new Configuration() { PropertyName = "VENDOR_NUMBER", StartPosition = 60, EndPosition = 65 });
            list.Add(new Configuration() { PropertyName = "ACTUAL_VENDOR", StartPosition = 66, EndPosition = 71 });
            list.Add(new Configuration() { PropertyName = "BANK_NUMBER", StartPosition = 72, EndPosition = 73 });
            list.Add(new Configuration() { PropertyName = "PO_NUMBER", StartPosition = 74, EndPosition = 93 });
            list.Add(new Configuration() { PropertyName = "INVOICE_NO", StartPosition = 94, EndPosition = 105 });
            list.Add(new Configuration() { PropertyName = "INVOICE_FILLER", StartPosition = 106, EndPosition = 106 });
            list.Add(new Configuration() { PropertyName = "INVOICE_REFER", StartPosition = 107, EndPosition = 111 });
            list.Add(new Configuration() { PropertyName = "ATTACHMENT_FLAG", StartPosition = 112, EndPosition = 112 });
            list.Add(new Configuration() { PropertyName = "CURRENCY_CODE", StartPosition = 113, EndPosition = 113 });
            list.Add(new Configuration() { PropertyName = "VENDOR_TERMS_CD", StartPosition = 114, EndPosition = 115 });
            list.Add(new Configuration() { PropertyName = "NEW_BATCH_NO", StartPosition = 116, EndPosition = 118 });
            list.Add(new Configuration() { PropertyName = "VENDOR_INDICATOR", StartPosition = 119, EndPosition = 119 });
            list.Add(new Configuration() { PropertyName = "IRS_UPD_IND", StartPosition = 120, EndPosition = 120 });
            list.Add(new Configuration() { PropertyName = "NO_OF_ITEMS", StartPosition = 121, EndPosition = 122 });
            list.Add(new Configuration() { PropertyName = "DETAIL_ITEM", StartPosition = 123, EndPosition = 123 });
            list.Add(new Configuration() { PropertyName = "UNIT_NUMBER", StartPosition = 124, EndPosition = 127 });
            list.Add(new Configuration() { PropertyName = "PRODUCT_LINE", StartPosition = 128, EndPosition = 129 });
            list.Add(new Configuration() { PropertyName = "UNIT_SUFFIX", StartPosition = 130, EndPosition = 130 });
            list.Add(new Configuration() { PropertyName = "FUEL_CODE", StartPosition = 131, EndPosition = 131 });
            list.Add(new Configuration() { PropertyName = "ACCOUNT_NUMBER", StartPosition = 132, EndPosition = 136 });
            list.Add(new Configuration() { PropertyName = "ODM_SERVICE_LOCN", StartPosition = 137, EndPosition = 140 });
            list.Add(new Configuration() { PropertyName = "DETAIL_AMOUNT", StartPosition = 141, EndPosition = 145 });
            list.Add(new Configuration() { PropertyName = "DETAIL_DISCOUNT", StartPosition = 146, EndPosition = 150 });
            list.Add(new Configuration() { PropertyName = "ODOMETER", StartPosition = 151, EndPosition = 154 });
            list.Add(new Configuration() { PropertyName = "CHARGE_COMPANY", StartPosition = 155, EndPosition = 156 });
            list.Add(new Configuration() { PropertyName = "CHARGE_DISTRICT", StartPosition = 157, EndPosition = 159 });
            list.Add(new Configuration() { PropertyName = "CHARGE_LOCATION", StartPosition = 160, EndPosition = 162 });
            list.Add(new Configuration() { PropertyName = "REASON_CODE", StartPosition = 163, EndPosition = 164 });
            list.Add(new Configuration() { PropertyName = "STATE_ORIGIN_CODE", StartPosition = 165, EndPosition = 166 });
            list.Add(new Configuration() { PropertyName = "APPROPRIATION_NO", StartPosition = 167, EndPosition = 174 });
            list.Add(new Configuration() { PropertyName = "BILL_OF_LADING", StartPosition = 175, EndPosition = 182 });
            list.Add(new Configuration() { PropertyName = "FUEL_INVOICE_NO", StartPosition = 183, EndPosition = 186 });
            list.Add(new Configuration() { PropertyName = "FUEL_INVOICE_DATE", StartPosition = 187, EndPosition = 190 });
            list.Add(new Configuration() { PropertyName = "FUELING_DATE", StartPosition = 191, EndPosition = 194 });
            list.Add(new Configuration() { PropertyName = "FUEL_VENDOR_NO", StartPosition = 195, EndPosition = 198 });
            list.Add(new Configuration() { PropertyName = "DETAIL_LABOR_AMT", StartPosition = 199, EndPosition = 203 });
            list.Add(new Configuration() { PropertyName = "DETAIL_PARTS_AMT", StartPosition = 204, EndPosition = 208 });
            list.Add(new Configuration() { PropertyName = "DETAIL_NONTX_AMT", StartPosition = 209, EndPosition = 213 });
            list.Add(new Configuration() { PropertyName = "CUSTOMER_NAME", StartPosition = 214, EndPosition = 243 });
            list.Add(new Configuration() { PropertyName = "COMMENT_DATA", StartPosition = 244, EndPosition = 338 });
            list.Add(new Configuration() { PropertyName = "DETAIL_QUANTITY", StartPosition = 339, EndPosition = 343 });
            list.Add(new Configuration() { PropertyName = "NEW_PROD_LINE", StartPosition = 344, EndPosition = 346 });
            list.Add(new Configuration() { PropertyName = "FUNCTION_CODE", StartPosition = 347, EndPosition = 348 });
            list.Add(new Configuration() { PropertyName = "COMDATA_PAYTYPE", StartPosition = 347, EndPosition = 347 });
            list.Add(new Configuration() { PropertyName = "COMDATA_PAY_DIRECT",StartPosition = 348,EndPosition = 348});

            return list;

        }

    }
}
