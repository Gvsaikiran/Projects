﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WalkerWebAPI
{
    public class walkerCollection
    {
        public List<walker> WalkerList { get; set; }
    }
    public class walker
    {
        public string SOURCE_PROGRAM { get; set; }
        public string ISSUE_LOCN { get; set; }
        public string EXPENSE_MONTH { get; set; }
        public string BATCH_NO { get; set; }
        public string REFER_NO { get; set; }
        public string REF_SEQUENCE { get; set; }
        public string SOURCE_TYPE { get; set; }
        public string ACCOUNTING_MONTH { get; set; }
        public string INVOICE_DRAFT_DATE { get; set; }
        public string CHECK_DRAFT_NUMBER { get; set; }
        public string DUE_DATE { get; set; }
        public string PROCESS_DATE { get; set; }
        public string PROCESS_TIME { get; set; }
        public string VENDOR_NUMBER { get; set; }
        public string ACTUAL_VENDOR { get; set; }
        public string BANK_NUMBER { get; set; }
        public string PO_NUMBER { get; set; }
        public string INVOICE_NO { get; set; }
        public string INVOICE_FILLER { get; set; }
        public string INVOICE_REFER { get; set; }
        public string ATTACHMENT_FLAG { get; set; }
        public string CURRENCY_CODE { get; set; }
        public string VENDOR_TERMS_CD { get; set; }
        public string NEW_BATCH_NO { get; set; }
        public string VENDOR_INDICATOR { get; set; }
        public string IRS_UPD_IND { get; set; }
        public string NO_OF_ITEMS { get; set; }
        public string DETAIL_ITEM { get; set; }
        public string UNIT_NUMBER { get; set; }
        public string PRODUCT_LINE { get; set; }
        public string UNIT_SUFFIX { get; set; }
        public string FUEL_CODE { get; set; }
        public string ACCOUNT_NUMBER { get; set; }
        public string ODM_SERVICE_LOCN { get; set; }
        public string DETAIL_AMOUNT { get; set; }
        public string DETAIL_DISCOUNT { get; set; }
        public string ODOMETER { get; set; }
        public string CHARGE_COMPANY { get; set; }
        public string CHARGE_DISTRICT { get; set; }
        public string CHARGE_LOCATION { get; set; }
        public string REASON_CODE { get; set; }
        public string STATE_ORIGIN_CODE { get; set; }
        public string APPROPRIATION_NO { get; set; }
        public string BILL_OF_LADING { get; set; }
        public string FUEL_INVOICE_NO { get; set; }
        public string FUEL_INVOICE_DATE { get; set; }
        public string FUELING_DATE { get; set; }
        public string FUEL_VENDOR_NO { get; set; }
        public string DETAIL_LABOR_AMT { get; set; }
        public string DETAIL_PARTS_AMT { get; set; }
        public string DETAIL_NONTX_AMT { get; set; }
        public string CUSTOMER_NAME { get; set; }
        public string COMMENT_DATA { get; set; }
        public string DETAIL_QUANTITY { get; set; }
        public string NEW_PROD_LINE { get; set; }
        public string FUNCTION_CODE { get; set; }
        public string COMDATA_PAYTYPE { get; set; }
        public string COMDATA_PAY_DIRECT { get; set; }

    }
}
