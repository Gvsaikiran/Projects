﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WalkerWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WalkerController : Controller
    {
        // GET api/walker
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value", "value1" };
        }

        // GET api/walker/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value5";
        }

        // POST api/walker
        [HttpPost]
        public HttpResponseMessage Post(walkerCollection dto)
        {
            //Get Data from db here        
            walker wobj = new walker();
            wobj.SOURCE_PROGRAM = "PORTAL";

            foreach (var wlobj in dto.WalkerList)
            {
                //Add conditions whichever you need it here
                if (wlobj.SOURCE_PROGRAM == wobj.SOURCE_PROGRAM)
                {

                }
                else {
                    //insert data in to database
                }
            }

            HttpResponseMessage obj = new HttpResponseMessage(HttpStatusCode.OK);
            

            return obj;
        }

    }
}